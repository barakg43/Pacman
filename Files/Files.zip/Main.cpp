#include <iostream>
#include <string.h>
#include "Point.h"
#include "Pacman.h"
#include "Ghost.h"
#include "GameBoard.h"
#include "Game.h"
using namespace std;

int main()
{
	Game game;

	game.start();

	return 0;
}