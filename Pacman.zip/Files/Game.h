#pragma once
#include "Pacman.h"
#include "Ghost.h"
#include "GameBoard.h"
#include "Color.h"
#include "GameMenu.h"

class Game:public GameMenu
{
public:
	enum DIRECTION { UP, DOWN, LEFT, RIGHT, STAY ,SIZE, NUM_OF_DIRECTION = 4};
	enum { ALLOW_STAY = 1, ALLOW_TUNNEL = 1, NORMAL_GAME_SPEED = 150, SLOW_GAME_SPEED = 250, FAST_GAME_SPEED = 75 };
	static bool active_color;
	
//	friend class Pacman;
private:
	enum GHOSTS{ NUM_OF_GHOSTS = 2, MOVE_COUNTER_ROUNDS = 10 };
	enum OPTION { ESC = 27, NOT_INIT = -1 };
	const Point GHOSTS_START_POS[NUM_OF_GHOSTS] = { {78,1},{10,2} };
	const Point PACMAN_START_POS = { 20, 10 };
	Pacman _pacman{ PACMAN_START_POS };
	Ghost _ghosts[NUM_OF_GHOSTS] = { {GHOSTS_START_POS[0], false }, {GHOSTS_START_POS[1], false } };
	char pacmanDir = NOT_INIT, tempDir = NOT_INIT;;
	static int gameSpeed;
	static GameBoard _board; // print class
	char _arrowKeys[DIRECTION::SIZE][2]; // the only allowed keys are: { 'w', 'W', 'a', 'A', 'x', 'X', 'd', 'D', 's', 'S' }
	enum KEYS{ w = 'w', W = 'W', a = 'a', A = 'A', x = 'x', X = 'X', d = 'd', D = 'D', s = 's', S = 'S' };
	int _moveCounter;
	int gameOption=NOT_INIT;
	GameMenu gameMenu;
	void resetGame();
public:

	//Constructors
	Game();


	void start();
	static bool isValidDirection(int key, const Point& currPos, bool allowedTunnel, bool allowStay);
	static void setGameSpeed(int speed);
	void gameLoop();
	

private://Met

	
	
	void checkPacmanHitsGhosts();
	void moveGhosts();
	void resetAllCharactersToInitPos();
	void pauseMode(bool& gamePause);
	int convertKeyToDirection(char key);


};