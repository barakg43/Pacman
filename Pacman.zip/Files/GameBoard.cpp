#include "GameBoard.h"
#include "Game.h"

// Constructors



char GameBoard::board[HEIGHT][WIDTH + 2]{

	//      1         2			3		  4			5		   6		7		  8
	//012345678901234567890123456789012345678901234567890123456789012345678901234567890"
	 "############################################     ###############################\n",//0
	 "#                                                                              #\n",//1
	 "#  ####      #######################    ##########                  ############\n",//2
	 "#  ####      #######################    ########################               #\n",//3
	 "#            ###                        ########         ##         ############\n", //4
	 "################  ###############################   ############################\n",//5
	 "################      ############################ #############################\n",//6
	 "#                                                                              #\n",//7
	 "#################    #############             #################################\n",//8
	 "#################    #############             #################################\n",//9
	 "                                                                                \n",//10
	 "####       ######################    ########################             ######\n",//11
	 "#####                #########            ###################   ######         #\n",//12
	 "#################################   #########################   ######         #\n",//13
	 "#                                                           #   ######         #\n",//14
	 "########    #######  ###################################        ################\n",//15
	 "######        #####  #########        ##################   ##                  #\n",//16
	 "###################  ##########      ###################   ##   #########   ####\n",//17
	 "#                                ##                        ##                  #\n",//18
	 "############################################     ###############################\n" //19 
};
GameBoard::GameBoard() {
	fillBreadCrumbs(false);
}

void GameBoard::print()
{
	clearScreen();
	
	if (Game::active_color)
	{

		for (int i = 0; i < HEIGHT; i++)
		{

			for (int j = 0; j < WIDTH; j++)
			{
				if (board[i][j] == WALL)
					setTextColor(Color::LIGHTCYAN);
				if (board[i][j] ==BREADCRUMBS)
					setTextColor(Color::LIGHTGREY);
				

				cout << board[i][j];


			}
			cout << endl;
		}
	}
		else
	{
			for (int i = 0; i < HEIGHT; i++)
				cout << board[i];

	}
	
	gotoxy(0, HEIGHT + 2);
	if (Game::active_color == 1)
		setTextColor(Color::LIGHTGREY);
	cout << "Lives:\nScore:" << endl;
	
	
}




void GameBoard::loadBoardFromFile(string fileName)
{
	ifstream boardFile(fileName);
		if (boardFile)
		{

			
			for (int row = 0; row < HEIGHT; row++)
			{
				boardFile.getline(board[row], WIDTH + 1);
				cout << board[row];
			}

		}
	else
	cout << "Faild to Open file";

	//	std::getline(boardFile, );



}

void GameBoard::printScoreToScreen(const int& score)
{
	
	gotoxy(7, HEIGHT + 3);
	cout << score;
}
void GameBoard::printLivesToScreen(const int& lives)
{
	

	
	gotoxy(7, HEIGHT + 2);
	cout << lives;
}
//the erase the invisible breadcrumbs in Pacman init position
void GameBoard::removeBreadCrumbsInPacmanPos(const Point& pos)
{
	int xPos = pos.getX();
	int yPos = pos.getY();
	numOfBreadCrumbs--;
	clearBreadcumbsInBoard(xPos, yPos);
}
void GameBoard::clearBreadcumbsInBoard(int x, int y)
{
	board[y][x] = BLANK;
}
void GameBoard::resetBoard()
{
	fillBreadCrumbs(true);
}
void GameBoard::fillBreadCrumbs(bool isGameReset)
{
	for (int row = 1; row < HEIGHT - 1; row++)
	{
		for (int col = 1; col < WIDTH - 1; col++)
			if (board[row][col] == BLANK)
			{
				board[row][col] = BREADCRUMBS;
				if (!isGameReset)//in case the game only reset board,dont increase the number of Bread Crumbs
					numOfBreadCrumbs++;
			}
	}
}