#pragma once
#include<iostream>
#include "Point.h"
#include "io_utils.h"
#include <fstream>
using namespace std;



class GameBoard
{

public:
	
	enum { HEIGHT = 25, WIDTH = 80, WALL = '#', BREADCRUMBS = '.', BLANK = ' ' };
	 
private:
	
	int numOfBreadCrumbs = 0;//to count how many breadcrumbs 'fillBreadCrumbs()' create
	static char board[HEIGHT][WIDTH + 2];//+2   '/n' and '/0'

public:
	// Constructors
	GameBoard();
	void print();
	static void printScoreToScreen(const int& score);
	static void printLivesToScreen(const int& lives);
	int getNumberOfBreadCrumbs() { return numOfBreadCrumbs; }
	void removeBreadCrumbsInPacmanPos(const Point& pos);
	static char getCurrBoardChar(int x, int y) { return board[y][x]; }
	void clearBreadcumbsInBoard(int x, int y);
	static void clearScreen() { system("cls"); }
	void resetBoard();
	void loadBoardFromFile(string fileName);
private:
	void fillBreadCrumbs(bool isGameReset);
};