Aya Bbu Shab
209226281
Barak Golan
313170730



#############################
bonuses we implemented:
#############################

game with colors:
 https://mama.mta.ac.il/mod/forum/discuss.php?d=3395

the pacman will remember next key and change when is valid direction
https://mama.mta.ac.il/mod/forum/discuss.php?d=3502

option to exit game in pause menu using 'G' or 'g'
https://mama.mta.ac.il/mod/forum/discuss.php?d=3557

user can change game speed 
https://mama.mta.ac.il/mod/forum/discuss.php?d=3652



